//
//  GameScene.swift
//  Breakout
//
//  Created by roycetanjiashing on 14/10/16.
//  Copyright © 2016 examplecompany. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene,SKPhysicsContactDelegate {
    var ball:SKSpriteNode!
    var paddle:SKSpriteNode!
    var loseZone:SKSpriteNode!
    var button = SKSpriteNode(imageNamed: "start")
    
    override func didMove(to view: SKView) {
        ball = self.childNode(withName: "Ball") as! SKSpriteNode
        paddle = self.childNode(withName: "Paddle") as! SKSpriteNode
        loseZone = self.childNode(withName: "LoseZone")as! SKSpriteNode
       button.position = CGPoint(x:self.frame.midX, y:self.frame.midY)
       self.addChild(button)
        
        let border = SKPhysicsBody(edgeLoopFrom: (view.scene?.frame)!)
        border.friction = 0
        self.physicsBody = border
        
        self.physicsWorld.contactDelegate = self
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let touchLocation = touch.location(in: self)
            paddle.position.x = touchLocation.x
            if button.contains(location) {
                button.alpha = 0
                ball.physicsBody?.applyImpulse(CGVector(dx: 100, dy: 100))
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchLocation = touch.location(in: self)
            paddle.position.x = touchLocation.x
        }
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyAName = contact.bodyA.node?.name
        let bodyBName = contact.bodyB.node?.name
        
        if bodyAName == "Ball" && bodyBName == "Brick" || bodyAName == "Brick" && bodyBName == "Ball"{
            if bodyAName == "Brick" {
                contact.bodyA.node?.removeFromParent()
            } else if bodyBName == "Brick" {
                contact.bodyB.node?.removeFromParent()
            }
            
            
        }
        
        func makeLoseZone() {
            let loseZone = SKSpriteNode(color: UIColor.red, size: CGSize(width: frame.width, height: 50))
            loseZone.position = CGPoint(x: frame.midX, y: frame.minY + 25)
            loseZone.name = "loseZone"
            loseZone.physicsBody = SKPhysicsBody(rectangleOf: loseZone.size)
            loseZone.physicsBody?.isDynamic = false
            addChild(button)
        }
        
        func resetGame() {
            let bodyAName = contact.bodyA.node?.name
            let bodyBName = contact.bodyB.node?.name
            
            if bodyAName == "Ball" && bodyBName == "LoseZone" || bodyAName == "LoseZone" && bodyBName == "Ball" {
                if bodyAName == "LoseZone" {
                    contact.bodyA.node?.removeFromParent()
                }
                else if bodyBName == "Ball" {
                    contact.bodyB.node?.removeFromParent()
                }
        }
            
    }
        
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
